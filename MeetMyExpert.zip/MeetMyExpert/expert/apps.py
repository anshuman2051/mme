from django.apps import AppConfig


class ExpertConfig(AppConfig):
    name = 'expert'
